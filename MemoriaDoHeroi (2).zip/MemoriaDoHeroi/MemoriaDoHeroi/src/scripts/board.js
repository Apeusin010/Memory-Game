class BoardManager{
    CardManager;
    node;
    numImg;
    curNumCards;
    constructor(id, numImg, cardManager){
        this.node = document.getElementById(id);
        this.CardManager = cardManager;
        this.numImg = numImg;
    }
    clear(){
        this.node.innerHTML = '';
    }
    fill(numberCards){
        if(numberCards>2*this.numImg){
            console.error('Error: Not enough images for ${numberCards} cards');
            numberCards = 2*this.numImg;
        }
        this.clear();
        this.addCards(this.CardManager.gen(1));
    }
    addCards(card){}
}